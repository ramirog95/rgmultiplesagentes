[Descargar el módulo 1.0(.zip)](https://github.com/ramirog95/rgmultiplesagentes/raw/main/rgmultiplesagentes.zip)
Módulo de prueba generado por Ramiro Grabinski.
Definición de versión en release.